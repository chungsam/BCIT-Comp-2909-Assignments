import { Component } from '@angular/core';

export class PlayingCard {
    cardVal:  string;
    suit:     string;
}

@Component({
    selector: 'my-app',
    // Multi-line content allowed with back ticks.
    template: `<h1>Hello world!  {{title}} <br/>
              <!-- Show cards in unordered list. -->
              <ul><li *ngFor="let card of cards" (click)="onSelect(card)"
	       [class.selected]="card === selectedCard">{{card.cardVal}}</li></ul>
              <div *ngIf="selectedCard">
                 <input [(ngModel)]="selectedCard.cardVal" placeholder="name"/>
              </div>`,
    styles:[`
        .selected {
            background-color: #CFD8DC;
            color: green;
        }`]
})


export class AppComponent { 
    public title = 'This is Angular 4!';
    // Include card data in class as public property.
    public cards = CARDS; 
    selectedCard: PlayingCard;
	
    onSelect(card: PlayingCard) { 
        this.selectedCard = card; 
    }
}

// Define card data.
var CARDS: PlayingCard[] = [
    { cardVal:"Ace", suit:"Spades"},
    { cardVal:"Two", suit:"Clubs"},
    { cardVal:"Six", suit:"Hearts"},
];
