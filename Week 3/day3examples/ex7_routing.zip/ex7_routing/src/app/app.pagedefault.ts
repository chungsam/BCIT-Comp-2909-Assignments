import { Component } from '@angular/core';
@Component({
    template: `This page does not exist.`
})
export class PageDefault { }
