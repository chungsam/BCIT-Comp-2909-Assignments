import { Component } from '@angular/core';
@Component({
    template: `This is green.<br/>`
})
export class GreenComponent { }
