import { Component } from '@angular/core';
@Component({
    template: `This is another page.`
})
export class PageBComponent { }
