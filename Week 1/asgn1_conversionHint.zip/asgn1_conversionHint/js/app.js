var cardApp = angular.module('cardApp', []);

// The controller is a constructor function that takes a $scope parameter.
// The controller lets us establish data binding between the controller and the view.
// The model is initialized with the $scope parameter.
cardApp.controller('MainController', ['$scope', function ($scope) {
    // Scope ensures that any changes to the 
    // model are reflected in the controller.
    // Here we create an initialize a 'title' model.
    $scope.greeting = "AngularJS Hello World!";
    
    // Define cards model which stores an array of objects.
    $scope.cards = [
        { "number": "2", "suit": "Hearts", "numOrd": 2 },
        { "number": "10", "suit": "Spades", "numOrd": 10 },
        { "number": "5", "suit": "Spades", "numOrd": 5 },
        { "number": "Q", "suit": "Hearts", "numOrd": 12 }
    ];
    
    $scope.formatRadio = "Long"; // set default format to 'L'
    $scope.selectedCard = {}; // create empty object.
    $scope.selectedCard.displaySuit = '';
    $scope.cardWasClicked = false;
    
    // Convert output between long and short suit formats.
    // ie. 'Hearts' and 'H'.
    $scope.formatOutput = function(selectedCard) {
        if(!$scope.cardWasClicked) {
            return; // nothing is selected yet.
        }
        $scope.selectedCard = selectedCard;
        $scope.selectedCard.displaySuit = selectedCard.suit;
        
        if($scope.formatRadio == 'Short') {
            // Get first character.
           $scope.selectedCard.displaySuit =  selectedCard.suit[0];
        }
    }
    
    // Find card from collection of cards.
    $scope.selectCard = function(num, suit) {
        $scope.cardWasClicked = true;
        for(i=0; i<$scope.cards.length; i++) {                
            if($scope.cards[i]['number'] == num &&
               $scope.cards[i]['suit'] == suit) {
                $scope.formatOutput($scope.cards[i]);
            }
        }
    }
}]);
