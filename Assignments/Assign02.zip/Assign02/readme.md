# Notes to Self

## Starting a simple webserver
To avoid CORS errors, set up a simple HTTP server using python:

``` python

python -m SimpleHTTPServer PORT

```