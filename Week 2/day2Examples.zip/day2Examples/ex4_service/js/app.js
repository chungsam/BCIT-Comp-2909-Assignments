/*****************************************
 * Declare application reference.
 *****************************************/
// Inject routing service and controller reference.
var cardApp = angular.module('cardApp', ['myControllers']);